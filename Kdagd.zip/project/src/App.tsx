import React, { useState } from 'react';
import { Upload, Search, BarChart3, FileText, AlertCircle } from 'lucide-react';
import type { Paper, EvaluationResult, ConferenceResult } from './lib/api';
import { evaluatePaper, getConferenceRecommendation, batchEvaluate } from './lib/api';

function App() {
  const [activeTab, setActiveTab] = useState('upload');
  const [papers, setPapers] = useState<Paper[]>([]);
  const [results, setResults] = useState<(EvaluationResult & ConferenceResult)[]>([]);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    setProcessing(true);
    setError(null);

    try {
      const newPapers: Paper[] = [];
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const content = await file.text();
        
        newPapers.push({
          paper_id: `P${String(papers.length + i + 1).padStart(3, '0')}`,
          content,
          metadata: {
            title: file.name,
            authors: [],
            keywords: [],
          },
        });
      }

      setPapers([...papers, ...newPapers]);
      const batchResults = await batchEvaluate(newPapers);
      setResults([...results, ...batchResults.results]);
      setActiveTab('analysis');
    } catch (err) {
      setError('Error processing papers. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <FileText className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-semibold">Research Paper Evaluator</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow">
          <div className="px-4 py-5 sm:p-6">
            <div className="border-b border-gray-200">
              <nav className="flex space-x-8">
                <TabButton
                  active={activeTab === 'upload'}
                  onClick={() => setActiveTab('upload')}
                  icon={<Upload className="h-5 w-5" />}
                  label="Upload"
                />
                <TabButton
                  active={activeTab === 'analysis'}
                  onClick={() => setActiveTab('analysis')}
                  icon={<Search className="h-5 w-5" />}
                  label="Analysis"
                />
                <TabButton
                  active={activeTab === 'results'}
                  onClick={() => setActiveTab('results')}
                  icon={<BarChart3 className="h-5 w-5" />}
                  label="Results"
                />
              </nav>
            </div>

            {error && (
              <div className="mt-4 p-4 bg-red-50 rounded-md flex items-center">
                <AlertCircle className="h-5 w-5 text-red-400 mr-2" />
                <span className="text-red-700">{error}</span>
              </div>
            )}

            <div className="mt-6">
              {activeTab === 'upload' && (
                <UploadSection
                  onFileUpload={handleFileUpload}
                  processing={processing}
                />
              )}
              {activeTab === 'analysis' && (
                <AnalysisSection
                  papers={papers}
                  results={results}
                  processing={processing}
                />
              )}
              {activeTab === 'results' && (
                <ResultsSection results={results} />
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

interface TabButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

function TabButton({ active, onClick, icon, label }: TabButtonProps) {
  return (
    <button
      onClick={onClick}
      className={`
        group inline-flex items-center px-4 py-4 border-b-2 font-medium text-sm
        ${active
          ? 'border-blue-500 text-blue-600'
          : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
        }
      `}
    >
      {icon}
      <span className="ml-2">{label}</span>
    </button>
  );
}

interface UploadSectionProps {
  onFileUpload: (event: React.ChangeEvent<HTMLInputElement>) => void;
  processing: boolean;
}

function UploadSection({ onFileUpload, processing }: UploadSectionProps) {
  return (
    <div className="flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-300 rounded-lg">
      <Upload className="h-12 w-12 text-gray-400" />
      <h3 className="mt-2 text-sm font-medium text-gray-900">Upload Research Papers</h3>
      <p className="mt-1 text-sm text-gray-500">PDF, DOC, or DOCX up to 10MB</p>
      
      <label className="mt-4">
        <input
          type="file"
          className="hidden"
          multiple
          accept=".pdf,.doc,.docx"
          onChange={onFileUpload}
          disabled={processing}
        />
        <span className={`
          inline-flex items-center px-4 py-2 rounded-md text-sm font-medium
          ${processing
            ? 'bg-gray-300 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700 cursor-pointer'
          }
          text-white
        `}>
          {processing ? 'Processing...' : 'Select Files'}
        </span>
      </label>
    </div>
  );
}

interface AnalysisSectionProps {
  papers: Paper[];
  results: (EvaluationResult & ConferenceResult)[];
  processing: boolean;
}

function AnalysisSection({ papers, results, processing }: AnalysisSectionProps) {
  const progress = (results.length / papers.length) * 100;

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
        <h3 className="text-lg font-medium text-gray-900">Processing Status</h3>
        <div className="mt-4">
          <div className="relative pt-1">
            <div className="flex mb-2 items-center justify-between">
              <div>
                <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                  Progress
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs font-semibold inline-block text-blue-600">
                  {progress.toFixed(0)}%
                </span>
              </div>
            </div>
            <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
              <div
                style={{ width: `${progress}%` }}
                className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-600 transition-all duration-500"
              />
            </div>
          </div>
          <p className="text-sm text-gray-500">
            Processed {results.length} of {papers.length} papers
          </p>
        </div>
      </div>
    </div>
  );
}

interface ResultsSectionProps {
  results: (EvaluationResult & ConferenceResult)[];
}

function ResultsSection({ results }: ResultsSectionProps) {
  return (
    <div className="space-y-6">
      {results.map((result) => (
        <div key={result.paper_id} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-medium text-gray-900">
                Paper {result.paper_id}
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                Confidence Score: {(result.confidence_score * 100).toFixed(1)}%
              </p>
            </div>
            <span className={`
              px-2 py-1 text-sm font-medium rounded-full
              ${result.publishable
                ? 'bg-green-100 text-green-800'
                : 'bg-red-100 text-red-800'
              }
            `}>
              {result.publishable ? 'Publishable' : 'Not Publishable'}
            </span>
          </div>

          <div className="mt-4">
            <h4 className="text-sm font-medium text-gray-900">Conference Recommendation</h4>
            <p className="mt-1 text-sm text-gray-600">{result.recommended_conference}</p>
            
            <h4 className="mt-4 text-sm font-medium text-gray-900">Alternative Conferences</h4>
            <ul className="mt-1 space-y-1">
              {result.alternative_conferences.map((conf, index) => (
                <li key={index} className="text-sm text-gray-600">{conf}</li>
              ))}
            </ul>

            <h4 className="mt-4 text-sm font-medium text-gray-900">Feedback</h4>
            <ul className="mt-1 space-y-1">
              {result.reasons.map((reason, index) => (
                <li key={index} className="text-sm text-gray-600">• {reason}</li>
              ))}
            </ul>

            {result.suggestions.length > 0 && (
              <>
                <h4 className="mt-4 text-sm font-medium text-gray-900">Suggestions</h4>
                <ul className="mt-1 space-y-1">
                  {result.suggestions.map((suggestion, index) => (
                    <li key={index} className="text-sm text-gray-600">• {suggestion}</li>
                  ))}
                </ul>
              </>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

export default App;