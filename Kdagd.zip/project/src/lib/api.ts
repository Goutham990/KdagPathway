import axios from 'axios';

const API_BASE_URL = '/api/v1';
const API_KEY = import.meta.env.VITE_API_KEY || '';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'X-API-Key': API_KEY,
    'Content-Type': 'application/json',
  },
});

export interface Paper {
  paper_id: string;
  content: string;
  metadata: {
    title: string;
    authors: string[];
    keywords: string[];
  };
}

export interface EvaluationResult {
  paper_id: string;
  publishable: boolean;
  confidence_score: number;
  reasons: string[];
  suggestions: string[];
}

export interface ConferenceResult {
  paper_id: string;
  recommended_conference: string;
  confidence_score: number;
  rationale: string;
  alternative_conferences: string[];
}

export const evaluatePaper = async (paper: Paper): Promise<EvaluationResult> => {
  const response = await api.post('/evaluate/publishability', paper);
  return response.data;
};

export const getConferenceRecommendation = async (
  paper_id: string,
  content: string,
  is_publishable: boolean
): Promise<ConferenceResult> => {
  const response = await api.post('/evaluate/conference', {
    paper_id,
    paper_content: content,
    is_publishable,
  });
  return response.data;
};

export const batchEvaluate = async (papers: Paper[]) => {
  const response = await api.post('/batch/evaluate', { papers });
  return response.data;
};